<?php
  include 'include/config.php';
 ?>

<?php
  include 'include/sidebar.php';
  include 'include/header.php';
  include 'include/body.php';
  include 'include/footer.php';
 ?>
