<?php
include 'include/header.php';
include 'include/config.php';
?>

<!-- <div class="d-flex" id="wrapper"> -->
  <?php include 'include/sidebar.php'; ?>
  <div id="page-content-wrapper">
    <nav class="navbar navbar-expand-lg navbar-light bg-transparent py-4 px-4">
      <div class="d-flex align-items-center">
        <i class="fas fa-bars primary-text fs-4 me-3" id="menu-toggle"></i>
        <h2 class="fs-2 m-0">Registrar Dashboard</h2>
      </div>
    </nav>


  <div class="container py-3">
    <div class="row">
      <div class="col-md-12">
        <div class="card ">
          <div class="card-header">
            <h1 align = "center">LIST OF ENROLLMENT SCHOOLYEAR</h1>
            <form class=""  method="post" align="center">
              <input type="text" name="Sy1" class="form-control" value="" placeholder="Insert School Year" required>
              <input type="submit" name="add1" value="Add" class="btn btn-primary">
            </form>

            <?php
            include('include/config.php');
            if(isset($_POST['add1'])){
              $sy = $_POST['Sy1'];

              $sql="SELECT schoolyear FROM  `uccp_enrollment_schedule` WHERE schoolyear = '$sy' ";
              $result = mysqli_query($conn,$sql);

              $rows = mysqli_num_rows($result);

              if($rows > 0){
                // echo "<script> alert('SCHOOLYEAR ALREADY EXIST')</script>";
              }else {
                $sql = mysqli_query($conn,"INSERT INTO `uccp_enrollment_schedule` (`schoolyear`,`status`,`sem`) VALUES ('$sy','0','0')");
                unset($_POST);
                // echo "<script> window.location='ENROLLMENT-SCHEDULING.php'</script>";
              }

            }
            ?>
            <form class=""  method="post" id="FORM" align="center">

              <!--<button type="button" name="open" class="btn btn-primary" id="BtnOpen" data-bs-toggle="modal" data-bs-target="#Open">Open</button>-->
              <button type="button" class="btn btn-primary openings">Open</button>


              <div class="modal" id="open1">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <!-- Modal Header -->
                    <div class="modal-header">
                      <h4 class="modal-title">Enrollment</h4>
                    </div>
                    <!-- Modal body -->
                    <div class="modal-bodys">

                    </div>

                    <!-- Modal footer -->
                    <div class="modal-footer">
                      <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                      <button type="submit" name="update1" class="btn btn-primary" id="BtnUpdate" data-bs-toggle="modal">
                        Start Enrollment
                        <?php

                        if(isset($_POST['update1'])){
                          $choices = $_POST['choices1'];
                          $semss = $_POST['sem'];


                          $sql = mysqli_query($conn,"UPDATE `uccp_enrollment_schedule` SET status = 'Closed' WHERE status = 'Open' ");
                          $sql = mysqli_query($conn,"UPDATE `uccp_enrollment_schedule` SET status = 'Open', sem ='$semss' WHERE schoolyear ='$choices'");
                          // echo "<script> window.location='ENROLLMENT-SCHEDULING.php'</script>";
                        }
                        ?>
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              <button type="submit" name="close" class="btn btn-danger" id="BtnClose" data-bs-toggle="modal">
                Close Enrollment

                <?php
                if(isset($_POST['close'])){
                  // $choices = $_POST['choices'];

                  $sql = mysqli_query($conn,"UPDATE `uccp_enrollment_schedule` SET status = 'Closed' WHERE status ='Open' ");
                  // echo "<script> window.location='ENROLLMENT-SCHEDULING.php'</script>";

                }
                ?>
              </button>
            </form>
          </div>

          <div class="card-body">
            <div class="" id="displayTable1"></div>
          </div>
        </div>
      </div>
    </div>
  </div>


  <div  id="edit1" class="modal fade"  role="dialog">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
      <div class="modal-content">
        <form class="" id="updateform" method="post">


          <div class="modal-header">
            <h4 class="modal-title">Update School Year</h4>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-bodyss" id="updateinfo">

            <div class="mx-3 mb-3">

              <label for="Courses" class="form-label">SCHOOL YEAR</label>
              <input type="text" class="form-control" id="updateSY1" placeholder="Update SCHOOL YEAR">

              <label for="Courses" class="form-label">SEMESTER</label>

              <select class="form-control" name="sem" id="updateSEM">
                <option value="" disabled>SELECT SEM</option>
                <option value="1st">1st</option>
                <option value="2nd">2nd</option>
                <option value="Summer">Summer</option>
              </select>

            </div>

          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-primary"  onclick="update1()">UPDATE</button>
            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
            <input type="hidden"  id="hidden">
          </div>
        </form>
      </div>
    </div>
  </div>

  <?php
  include 'include/footer.php';
  ?>

  <script>

  $(document).ready(function(){
    var table =  $('#enrolltbl').DataTable();
    displayData1();


    $('.openings').click(function(){

      $.ajax({
        url: 'select-sy.php',
        type: 'post',
        success: function(response){
          $('.modal-bodys').html(response);
          $('#open1').modal('show');

        }
      });
    });

  })

  function displayData1(){

    var display ="true";

    $.ajax({

      url:'table-Enrollment.php',
      type: 'post',
      data: {display: display},
      success:function(data,status){
        $('#displayTable1').html(data);
      }
    })
  }


  function remove1(id){

    if(confirm('Are you sure you wantt to Reject This Applicant?')){

      $.ajax({
        url:'remove-sched.php',
        type:'post',
        data:{remove:id},
        success:function(data){
          displayData1();
          $('#row'+id).hide('slow');

        }

      });

    }
  }

  function edit1(uenrollid){
    $('#hidden').val(uenrollid);

    $.post("update-enrollment.php",{uenrollid:uenrollid},function(data,
      status){
        var id = JSON.parse(data);
        $('#updateSY1').val(id.schoolyear);
        $('#updateSEM').val(id.sem);
      });
      $('#edit1').modal("show");
    }


    function update1(){

      var updateSY1 = $('#updateSY1').val();
      var updateSEM = $('#updateSEM').val();
      var hidden= $('#hidden').val();


      $.post("update-enrollment.php", {
        updateSY1:updateSY1, hidden:hidden,updateSEM:updateSEM
      },function(data,status){
        displayData1();
        $('#edit1').modal("hide");
      });

    }

    </script>
