<?php
include 'include/header.php';
include 'include/config.php';
?>

<!-- <div class="d-flex" id="wrapper"> -->
  <?php include 'include/sidebar.php'; ?>
  <div id="page-content-wrapper">
    <nav class="navbar navbar-expand-lg navbar-light bg-transparent py-4 px-4">
      <div class="d-flex align-items-center">
        <i class="fas fa-bars primary-text fs-4 me-3" id="menu-toggle"></i>
        <h2 class="fs-2 m-0">Registrar Dashboard</h2>
      </div>
    </nav>
    <div class="container py-3">
      <div class="row">
        <div class="col-md-12">
          <div class="container">
            <div class="card">
              <div class="card-header">
                <h1 align = "center">LIST OF ADMISSION SCHOOLYEAR</h1>
                <form class=""  method="post" align ="center">
                  <input class="form-control" type="text" name="Sy" value="" placeholder="Insert School Year" required>
                  <input type="submit" name="add" value="Add" class="btn btn-primary">
                </form>

                <?php
                include('include/config.php');
                if(isset($_POST['add'])){
                  $sy = $_POST['Sy'];

                  $sql="SELECT schoolyear FROM  `uccp_admission_schedule` WHERE schoolyear = '$sy' ";
                  $result = mysqli_query($conn,$sql);
                  $rows = mysqli_num_rows($result);
                  if($rows > 0){
                    // echo "<script> alert('SCHOOLYEAR ALREADY EXIST')</script>";
                  }else {
                    $sql = mysqli_query($conn,"INSERT INTO `uccp_admission_schedule`(`schoolyear`,`status`) VALUES ('$sy','0')");
                    unset($_POST);
                    // echo "<script> window.location='ADMISSION-SCHEDULING.php'</script>";
                  }
                }
                ?>
                <form class=""  method="post" id="FORM" align ="center">
                  <!-- <button type="button" name="open" class="btn btn-primary" id="BtnOpen" data-bs-toggle="modal" data-bs-target="#Open">Open</button> -->
                  <button type="button" class="btn btn-primary opening">Open</button>

                  <div class="modal" id="Open">
                    <div class="modal-dialog">
                      <div class="modal-content">
                        <!-- Modal Header -->
                        <div class="modal-header">
                          <h4 class="modal-title">Admission</h4>
                        </div>
                        <!-- Modal body -->
                        <div class="modal-body">
                          <select class="" name="choices">
                            <?php
                            $choices = $_POST['choices'];
                            $sql="SELECT schoolyear,id FROM  `uccp_admission_schedule` ";
                            $result = mysqli_query($conn,$sql);
                            while($row = mysqli_fetch_assoc($result)){
                              echo '<option>'.$row['schoolyear'].'</option>';
                            }
                            ?>
                          </select>
                        </div>

                        <!-- Modal footer -->
                        <div class="modal-footer">
                          <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                          <button type="submit" name="update" class="btn btn-primary" id="BtnUpdate" data-bs-toggle="modal">
                            Start Admission
                            <?php

                            if(isset($_POST['update'])){
                              $choices = $_POST['choices'];

                              $sql = mysqli_query($conn,"UPDATE `uccp_admission_schedule` SET status = 'Closed' WHERE status = 'Open'");
                              $sql = mysqli_query($conn,"UPDATE `uccp_admission_schedule` SET status = 'Open' WHERE schoolyear ='$choices'");
                              // echo "<script> window.location='ADMISSION-SCHEDULING.php'</script>";


                            }
                            ?>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>

                  <button type="submit" name="close1" class="btn btn-danger" id="BtnClose" data-bs-toggle="modal">
                    Close Admission

                    <?php
                    if(isset($_POST['close1'])){
                      // $choices = $_POST['choices'];
                      $sql = mysqli_query($conn,"UPDATE `uccp_admission_schedule` SET status = 'Closed' WHERE status ='Open'");
                      // echo "<script> window.location='ADMISSION-SCHEDULING.php'</script>";
                    }
                    ?>
                  </button>
                </form>
              </div>
              <div class="card-body">
                <div class="" id="displayTable"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div  id="edit3" class="modal fade"  role="dialog">
      <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content">
          <form class="" id="updateform" method="post">

            <div class="modal-header">
              <h4 class="modal-title">Update School Year</h4>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-bodys" id="updateinfo">

              <div class="mx-3 mb-3">

                <label for="Courses" class="form-label">SCHOOL YEAR</label>
                <input type="text" class="form-control" id="updateSY" placeholder="Update SCHOOL YEAR">

              </div>

            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-primary"   onclick="update3()">UPDATE</button>
              <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
              <input type="hidden"  id="hidden">
            </div>
          </form>
        </div>
      </div>
    </div>

    <?php
    include 'include/footer.php';
    ?>

    <script>

    $(document).ready(function(){

      displayData();

      $('.opening').click(function(){

        $.ajax({
          url: 'select-sy-admission.php',
          type: 'post',
          success: function(response){
            $('.modal-body').html(response);
            $('#Open').modal('show');

          }
        });
      });

    })


    function displayData(){

      var display ="true";

      $.ajax({

        url:'table-admission.php',
        type: 'post',
        data: {display: display},
        success:function(data,status){
          $('#displayTable').html(data);
        }


      })

    }

    function remove(id){

      if(confirm('Are you sure you wantt to Reject This Applicant?')){

        $.ajax({
          url:'remove-sched-admission.php',
          type:'post',
          data:{remove:id},
          success:function(data){
            displayData();
            $('#row'+id).hide('slow');

          }

        });

      }
    }




    function edit(uid){
      $('#hidden').val(uid);

      $.post("update-admission.php",{uid:uid},function(data,
        status){
          var id = JSON.parse(data);

          $('#updateSY').val(id.schoolyear);

        });
        $('#edit3').modal("show");
      }




      function update3(){

        var updateSY = $('#updateSY').val();
        var hidden= $('#hidden').val();


        $.post("update-admission.php", {
          updateSY:updateSY, hidden:hidden
        },function(data,status){
          displayData();
          $('#edit3').modal("hide");
        });

      }



      </script>

    </div>
